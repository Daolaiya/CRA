import boto3
from botocore.exceptions import ClientError

# AWS service clients are initialized outside the handler so they can
# be reused across Lambda invocations.
datazone = boto3.client("datazone")
sts = boto3.client("sts")

# Retrieve account metadata used when constructing DataZone data source names.
identity = sts.get_caller_identity()
catalog_id = identity["Account"]
catalog_name = "AwsDataCatalog"


def get_data_source_id(
    domain_id: str,
    project_id: str,
    data_source_name: str
):
    """
    Retrieve the DataZone data source identifier for the specified name.

    Returns:
        str: Existing data source identifier.
        None: If no matching data source exists.
    """
    try:
        response = datazone.list_data_sources(
            domainIdentifier=domain_id,
            projectIdentifier=project_id,
            name=data_source_name
        )

        if response["items"]:
            return response["items"][0]["dataSourceId"]

        return None

    except ClientError as err:
        print(
            f"List data sources failed, "
            f"domainIdentifier={domain_id}, "
            f"projectIdentifier={project_id}: {err}"
        )
        raise


def lambda_handler(event, context):
    """
    Start a DataZone data source run for a Glue database.

    Expected event payload:

    {
        "database": "dev1_kg01_bronze_klmt1_gluedb",
        "domain_id": "dzd-xxxxxxxx",
        "project_id": "proj-xxxxxxxx"
    }
    """

    # Validate required invocation parameters.
    required_fields = [
        "database",
        "domain_id",
        "project_id"
    ]

    missing_fields = [
        field for field in required_fields
        if not event.get(field)
    ]

    if missing_fields:
        raise ValueError(
            f"Missing required event parameter(s): "
            f"{', '.join(missing_fields)}"
        )

    database = event.get("database")
    domain_id = event.get("domain_id")
    project_id = event.get("project_id")

    # Data source name follows the established naming convention.
    data_source_name = (
        f"{catalog_id}-{catalog_name}-{database}-datasource"
    )

    data_source_id = get_data_source_id(
        domain_id,
        project_id,
        data_source_name
    )

    if data_source_id is None:
        raise ValueError(
            f"Data source not found: {data_source_name}"
        )

    try:
        # Trigger an ingestion run for the DataZone data source.
        datazone.start_data_source_run(
            domainIdentifier=domain_id,
            dataSourceIdentifier=data_source_id
        )

        print(
            f"Data source run started, "
            f"name={data_source_name}, "
            f"id={data_source_id}"
        )

    except ClientError as err:
        print(
            f"Data source run failed, "
            f"name={data_source_name}, "
            f"id={data_source_id}: {err}"
        )
        raise

    return {
        "dataSourceIdentifier": data_source_id
    }