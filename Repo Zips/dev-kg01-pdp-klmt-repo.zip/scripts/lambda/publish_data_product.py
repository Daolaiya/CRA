import boto3
from botocore.exceptions import ClientError

# AWS service clients are initialized outside the handler so they can
# be reused across Lambda invocations.
datazone = boto3.client("datazone")
sts = boto3.client("sts")

# Retrieve account metadata used when constructing DataZone names.
identity = sts.get_caller_identity()
catalog_id = identity["Account"]
catalog_name = "AwsDataCatalog"


def lambda_handler(event, context):
    """
    Create and publish a DataZone data product for a Glue database.

    Expected event payload:

    {
        "database": "dev1_kg01_bronze_klmt1_gluedb",
        "domain_id": "dzd-xxxxxxxx",
        "project_id": "proj-xxxxxxxx"
    }
    """

    # Validate required invocation parameters.
    required_fields = [
        "database",
        "domain_id",
        "project_id"
    ]

    missing_fields = [
        field for field in required_fields
        if not event.get(field)
    ]

    if missing_fields:
        raise ValueError(
            f"Missing required event parameter(s): "
            f"{', '.join(missing_fields)}"
        )

    database = event.get("database")
    domain_id = event.get("domain_id")
    project_id = event.get("project_id")

    data_product_name = f"{database}_{project_id}"
    data_product_desc = (
        f"SMUS data product for Glue database {database}"
    )

    print(
        f"Searching domain_id={domain_id}, "
        f"project_id={project_id}, "
        f"for assets in database={database}"
    )

    # Gather all catalog assets associated with the Glue database.
    data_product_assets = []
    next_token = None

    while True:

        search_kwargs = {
            "domainIdentifier": domain_id,
            "owningProjectIdentifier": project_id,
            "searchScope": "ASSET",
            "searchText": database,
            "maxResults": 50
        }

        if next_token:
            search_kwargs["nextToken"] = next_token

        try:
            response = datazone.search(**search_kwargs)

        except ClientError as err:
            print(
                f"Asset search failed, "
                f"database={database}: {err}"
            )
            raise

        for item in response.get("items", []):

            asset = item.get("assetItem")

            if not asset:
                continue

            external_id = asset.get(
                "externalIdentifier",
                ""
            )

            # Only include assets belonging to the target database.
            if database in external_id:

                data_product_assets.append(
                    {
                        "itemType": "ASSET",
                        "identifier": asset["identifier"]
                    }
                )

                print(
                    f"Found asset {asset['name']}, "
                    f"identifier={asset['identifier']}, "
                    f"externalIdentifier={external_id}"
                )

        next_token = response.get("nextToken")

        if not next_token:
            break

    try:
        # Create a DataZone data product from the discovered assets.
        response = datazone.create_data_product(
            domainIdentifier=domain_id,
            name=data_product_name,
            owningProjectIdentifier=project_id,
            description=data_product_desc,
            items=data_product_assets
        )

        data_product_id = response["id"]

        print(
            f"Data product created, "
            f"name={response.get('name', 'none')}, "
            f"id={response['id']}"
        )

    except datazone.exceptions.ConflictException:
        print(
            f"Data product already exists, "
            f"name={data_product_name}"
        )

        return False

    except ClientError as err:
        print(
            f"Create data product failed, "
            f"name={data_product_name}: {err}"
        )
        raise

    try:
        # Publish the data product to create a catalog listing.
        response = datazone.create_listing_change_set(
            domainIdentifier=domain_id,
            entityIdentifier=data_product_id,
            entityType="DATA_PRODUCT",
            action="PUBLISH"
        )

        print(
            f"Data product published, "
            f"listingId={response['listingId']}, "
            f"status={response['status']}"
        )

    except ClientError as err:
        print(
            f"Publish data product failed, "
            f"dataProductId={data_product_id}: {err}"
        )
        raise

    return {
        "dataProductIdentifier": data_product_id
    }