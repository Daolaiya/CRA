import boto3
from botocore.exceptions import ClientError

# AWS service clients are initialized outside the handler so they can
# be reused across Lambda invocations.
datazone = boto3.client("datazone")
sts = boto3.client("sts")

# Retrieve account metadata used when constructing DataZone data source names.
identity = sts.get_caller_identity()
catalog_id = identity["Account"]
catalog_name = "AwsDataCatalog"


def get_data_source_id(
    domain_id: str,
    project_id: str,
    data_source_name: str
):
    """
    Retrieve the DataZone data source identifier for the specified name.

    Returns:
        str: Existing data source identifier.
        None: If no matching data source exists.
    """
    try:
        response = datazone.list_data_sources(
            domainIdentifier=domain_id,
            projectIdentifier=project_id,
            name=data_source_name
        )

        if response["items"]:
            return response["items"][0]["dataSourceId"]

        return None

    except ClientError as err:
        print(
            f"List data sources failed, "
            f"domainIdentifier={domain_id}, "
            f"projectIdentifier={project_id}: {err}"
        )
        raise


def lambda_handler(event, context):
    """
    Create a DataZone data source for a Glue database if one does not
    already exist.

    Expected event payload:

    {
        "database": "dev1_kg01_bronze_klmt1_gluedb",
        "domain_id": "dzd-xxxxxxxx",
        "project_id": "proj-xxxxxxxx"
    }
    """

    # Validate required invocation parameters.
    required_fields = [
        "database",
        "domain_id",
        "project_id"
    ]

    missing_fields = [
        field for field in required_fields
        if not event.get(field)
    ]

    if missing_fields:
        raise ValueError(
            f"Missing required event parameter(s): "
            f"{', '.join(missing_fields)}"
        )

    database = event.get("database")
    domain_id = event.get("domain_id")
    project_id = event.get("project_id")

    try:
        # Retrieve the project's default lakehouse connection.
        # This connection is required when creating a GLUE data source.
        response = datazone.list_connections(
            domainIdentifier=domain_id,
            projectIdentifier=project_id,
            name="project.default_lakehouse"
        )

        if not response["items"]:
            raise ValueError(
                "No DataZone connection found with name "
                "'project.default_lakehouse'"
            )

        connection_id = response["items"][0]["connectionId"]

    except ClientError as err:
        print(
            f"List connections failed, "
            f"domainIdentifier={domain_id}, "
            f"projectIdentifier={project_id}: {err}"
        )
        raise

    # Data source name follows the established naming convention.
    data_source_name = (
        f"{catalog_id}-{catalog_name}-{database}-datasource"
    )

    data_source_desc = (
        f"SMUS data source for Glue database {database}"
    )

    # Check whether this Glue database has already been registered
    # as a DataZone data source.
    data_source_id = get_data_source_id(
        domain_id,
        project_id,
        data_source_name
    )

    if data_source_id is None:

        try:
            # Register the Glue database as a DataZone data source.
            response = datazone.create_data_source(
                name=data_source_name,
                description=data_source_desc,
                domainIdentifier=domain_id,
                projectIdentifier=project_id,
                connectionIdentifier=connection_id,
                type="GLUE",
                configuration={
                    "glueRunConfiguration": {
                        "relationalFilterConfigurations": [
                            {
                                "databaseName": database,
                                "filterExpressions": [
                                    # Exclude metadata/control tables that
                                    # should not be cataloged.
                                    {
                                        "type": "EXCLUDE",
                                        "expression": "table_load_status"
                                    },
                                    # Only include the required business table.
                                    {
                                        "type": "INCLUDE",
                                        "expression": "*"
                                    }
                                ]
                            }
                        ]
                    }
                },
                schedule={
                    # Daily refresh at 08:00 Montreal time.
                    "schedule": "cron(0 8 * * ? *)",
                    "timezone": "AMERICA_MONTREAL"
                }
            )

            data_source_id = response["id"]
            data_source_status = response["status"]

            # Wait until DataZone completes creation of the data source.
            while data_source_status == "CREATING":

                response = datazone.get_data_source(
                    domainIdentifier=domain_id,
                    identifier=data_source_id
                )

                print(
                    f"Creating data source "
                    f"{response.get('name', 'unknown')}, "
                    f"id={response['id']}, "
                    f"status={response['status']}"
                )

                data_source_status = response["status"]

            print(
                f"Data source "
                f"{response.get('name', 'unknown')} "
                f"created, id={response['id']}"
            )

        except datazone.exceptions.ValidationException as err:
            print(
                f"Data source {data_source_name} "
                f"already exists: {err}"
            )

        except ClientError as err:
            print(f"Data source creation failed: {err}")
            raise

    return {
        "dataSourceIdentifier": data_source_id
    }