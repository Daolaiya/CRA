import boto3
import json

s3 = boto3.client("s3")

def parse_s3_path(path):
    parts = path.replace("s3://", "").split("/", 1)
    return parts[0], parts[1]

def lambda_handler(event, context):
    run_id = event["run_id"].strip()
    spoke_path = event["spoke_path"].strip()
    target_db = event["target_database"].strip()

    path = f"{spoke_path.rstrip('/')}/summary/{run_id}.json"
    bucket, key = parse_s3_path(path)

    obj = s3.get_object(Bucket=bucket, Key=key)
    data = json.loads(obj["Body"].read())

    # =========================
    # Build formatted message
    # =========================
    message = f"{target_db} completed.\n\n"

    # ✅ SUCCESS TABLE (formatted grid)
    if data.get("success"):
        # ✅ dynamic + minimum width
        MIN_COUNT_WIDTH = 12   # enough for billions (e.g. 123,456,789)
        MIN_TABLE_WIDTH = 15

        # compute actual lengths
        max_table_len = max(len(t["table_name"]) for t in data["success"])
        max_count_len = max(len(f"{t['target_count']:,}") for t in data["success"])

        table_col = max(max_table_len, len("table_name"), MIN_TABLE_WIDTH)
        count_col = max(max_count_len, len("count"), MIN_COUNT_WIDTH)

        # borders
        border = f"+-{'-'*table_col}-+-{'-'*count_col}-+\n"
        header = f"| {'table_name':<{table_col}} | {'count':>{count_col}} |\n"

        message += border
        message += header
        message += border

        # ✅ sort for readability (optional but recommended)
        for t in sorted(data["success"], key=lambda x: x["target_count"], reverse=True):
            table = t["table_name"]
            count = f"{t['target_count']:,}"   # ✅ comma formatting
            message += f"| {table:<{table_col}} | {count:>{count_col}} |\n"

        message += border

    # ✅ SKIPPED
    if data.get("skipped"):
        message += "\nSkipped tables:\n"
        for t in data["skipped"]:
            message += f"  - {t['table_name']} ({t['reason']})\n"

    # ✅ FAILED
    if data.get("failed"):
        message += "\nFailed tables:\n"
        for t in data["failed"]:
            message += f"  - {t['table_name']} ({t['reason']})\n"

    return {"message": message}