dev-kg01-pdp-rhru-repo
dev-kg01-pdp-rhru-repo is the CodeCommit repository for Program Authority Rules (CDS) AWS resources used within PDP.