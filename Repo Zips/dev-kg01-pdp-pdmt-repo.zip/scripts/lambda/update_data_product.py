import boto3
from botocore.exceptions import ClientError

# AWS service clients are initialized outside the handler so they can
# be reused across Lambda invocations.
datazone = boto3.client("datazone")
sts = boto3.client("sts")

# Retrieve account metadata used when constructing DataZone names.
identity = sts.get_caller_identity()
catalog_id = identity["Account"]
catalog_name = "AwsDataCatalog"


def get_data_product_id(
    domain_id: str,
    project_id: str,
    data_product_name: str
):
    """
    Search for a DataZone data product by name.

    Returns:
        str: Data product identifier.
        None: If the data product does not exist.
    """
    try:
        response = datazone.search(
            domainIdentifier=domain_id,
            owningProjectIdentifier=project_id,
            searchScope="DATA_PRODUCT",
            searchText=data_product_name,
            maxResults=1
        )

        if response["items"]:
            return response["items"][0]["dataProductItem"]["id"]

        return None

    except ClientError as err:
        print(
            f"Search for data product failed, "
            f"name={data_product_name}: {err}"
        )
        raise


def get_database_asset_ids(
    domain_id: str,
    project_id: str,
    database_name: str
) -> list"""
    Return all DataZone asset identifiers associated with
    a given Glue database.
    """
    data_product_assets = []
    next_token = None

    while True:

        search_kwargs = {
            "domainIdentifier": domain_id,
            "owningProjectIdentifier": project_id,
            "searchScope": "ASSET",
            "searchText": database_name,
            "maxResults": 50
        }

        if next_token:
            search_kwargs["nextToken"] = next_token

        try:
            response = datazone.search(**search_kwargs)

        except ClientError as err:
            print(
                f"Asset search failed, "
                f"database={database_name}: {err}"
            )
            raise

        for item in response.get("items", []):

            asset = item.get("assetItem")

            if not asset:
                continue

            external_id = asset.get(
                "externalIdentifier",
                ""
            )

            if database_name in external_id:

                data_product_assets.append(
                    {
                        "itemType": "ASSET",
                        "identifier": asset["identifier"]
                    }
                )

                print(
                    f"Found asset {asset['name']}, "
                    f"identifier={asset['identifier']}, "
                    f"externalIdentifier={external_id}"
                )

        next_token = response.get("nextToken")

        if not next_token:
            break

    return data_product_assets


def lambda_handler(event, context):
    """
    Look up an existing DataZone data product associated
    with a Glue database.

    Expected event payload:

    {
        "database": "dev_kg01_bronze_fr001_gluedb",
        "domain_id": "dzd-xxxxxxxx",
        "project_id": "proj-xxxxxxxx"
    }
    """

    # Validate required invocation parameters.
    required_fields = [
        "database",
        "domain_id",
        "project_id"
    ]

    missing_fields = [
        field for field in required_fields
        if not event.get(field)
    ]

    if missing_fields:
        raise ValueError(
            f"Missing required event parameter(s): "
            f"{', '.join(missing_fields)}"
        )

    database = event.get("database")
    domain_id = event.get("domain_id")
    project_id = event.get("project_id")

    data_product_name = f"{database}_{project_id}"

    print(
        f"Searching domain_id={domain_id}, "
        f"project_id={project_id}, "
        f"for data product name={data_product_name}"
    )

    try:
        data_product_id = get_data_product_id(
            domain_id,
            project_id,
            data_product_name
        )

        if data_product_id is None:
            print(
                f"Data product not found, "
                f"name={data_product_name}"
            )

            return {
                "dataProductIdentifier": None
            }

        print(
            f"Data product found, "
            f"name={data_product_name}, "
            f"id={data_product_id}"
        )

    except ClientError as err:
        print(
            f"Search for data product failed, "
            f"name={data_product_name}: {err}"
        )
        raise

    return {
        "dataProductIdentifier": data_product_id
    }