# dev-kg01-pdp-avmt-repo

dev-kg01-pdp-avmt-repo is the CodeCommit repository for GST/HST Audit System AWS resources used within PDP.