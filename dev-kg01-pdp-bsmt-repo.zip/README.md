# dev-kg01-pdp-bsmt-repo

dev-kg01-pdp-bsmt-repo is the CodeCommit repository for Compliance Systems Master - INTEGRAS AWS resources used within PDP.