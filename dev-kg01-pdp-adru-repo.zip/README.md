# dev-kg01-pdp-adru-repo

dev-kg01-pdp-adru-repo is the CodeCommit repository for Modus – Workload Rule (ADRU) AWS resources used within PDP.