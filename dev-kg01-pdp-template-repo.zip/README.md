# Code Repository - dev-kg01-pdp-<dbid>-repo

## Overview

This repository contains AWS Cloud Formation templates and scripts used to deploy and manage <source description> (dbid).

The stack provisions:
- IAM Roles
- IAM Managed Policies
- Glue database
- Glue tables
- Glue jobs
- Lambda functions
- EventBridge rules
- SNS Topics

---

## Contacts

| Role | Team |
|---------|----------|
| Repository Owner | Program Data Provider |

---

## Architecture Overview

The infrastructure is organized using a main stack and multiple nested stacks separated by AWS service type.

```
Main Stack
│
├── Events Stack
│   └── Rule
│
├── Glue Stack
│   ├── Database
│   └── Table
│
├── Glue Job Stack
│   └── Job
│
├── IAM Stack
│   ├── Managed Policy
│   └── Role
│
├── Lake Formation Stack
│   └── Permissions
│
├── Lambda Stack
│   └── Function
│
└── SNS Stack
    └── Topic
```

---

## Clone Repository

```
git clone codecommit::ca-central-1://dev-kg01-pdp-template-repo <local>
```

---

## Repository Structure

```
.
├───infra/
|   ├───params/
|   |   ├───pipeline-config-dev.json
|   |   ├───pipeline-config-test.json
|   |   └───pipeline-config-prod.json
|   |
|   └──templates/
|       ├───nested/
|       |   ├───events-cfn.yaml
|       |   ├───glue-cfn.yaml
|       |   ├───glue-job-cfn.yaml
|       |   ├───iam-cfn.yaml
|       |   ├───lakeformation-cfn.yaml
|       |   ├───lambda-cfn.yaml
|       |   └───sns-cfn.yaml
|       |
|       └───main-cfn.yaml
|
├───scripts/
|   ├───glue/
|   |   └───active-view-etl.py
|   └───lambda/
|       ├───create-smus-data-source.py
|       ├───run-smus-data-source.py
|       └───publish-data-product.py
|
└───README.md
```

---

## Environment Configuration

Environment-specific parameters are stored in:

```
.
└───infra/
    └───params/
        ├───pipeline-config-dev.json
        ├───pipeline-config-test.json
        └───pipeline-config-prod.json
```